from django.shortcuts import render, redirect
from .forms import TareaForm
from .models import tarea
# Create your views here.
def home(request):
    tareas =tarea.objects.all()
    context={'tareas':tareas}
    return render(request, 'home.html', context)


def agregar(request):
    if request.method =="POST":
        form= TareaForm(request.POST)
        if form.is_valida():
            form.save()
            return redirect('home')
        else: 
            form =TareaForm()
        context = {'form': form}
        return render(request, 'agregar.html', context)
    