from django import forms 
from .models import tarea
class TareaForm(forms.ModelForm):
    class Meeta: 
        modeel= tarea 
        fields= ['tarea']