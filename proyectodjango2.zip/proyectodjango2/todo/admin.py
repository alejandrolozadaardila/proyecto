from django.contrib import admin
from .models import tarea 
admin.site.register(tarea)

# Register your models here.
